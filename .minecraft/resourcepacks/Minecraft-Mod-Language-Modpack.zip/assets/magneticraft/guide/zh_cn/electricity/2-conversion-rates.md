# 转换率

**瓦**
- 1 J = 1 RF
- 1 J = 0.25 EU
- 1 J = 1 FE (forge energy)
- 1 Watt = 1 J/t

- (Watt)瓦特是流量
- (J)焦耳是能量

**蒸汽**
- 1 J = 蒸汽 0.5mb 
- 水|1mb = 蒸汽 10mb

- 太阳半径: 695.700 km