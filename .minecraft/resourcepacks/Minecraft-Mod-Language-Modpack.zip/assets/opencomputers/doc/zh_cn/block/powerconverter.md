# Power Converter

![One of us? One of us!](oredict:oc:powerConverter)

能源转换器是最快捷的使用其他mod能源的办法了. 
如果只是运行单台机器，那么不需要造这个东西。 如果你有一个只是偶尔使用的大电容你也不用做这个方块
然而如果你想直接驱动[装配机](assembler.md) 或者 [充电机](charger.md),
这个东西往往比直接连接外部能源要给力