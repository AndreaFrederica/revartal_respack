# 适配器

![Now with 100% more everything.](oredict:oc:adapter)

允许 [电脑](../general/computer.md) 与原版和其他mod的方块交互. 相邻的支持方块将会在连接适配器的 [电脑](../general/computer.md) 显示

适配器还有多种选择器升级.比如, the [物品控制器升级](../item/inventoryControllerUpgrade.md) 允许电脑从相邻适配器的方块中获取更详细的物品信息, 就像这个升级呗安装在设备里面一样 (比如[机器人](robot.md) or [无人机](../item/drone.md)), and a [储罐控制器升级](../item/tankControllerUpgrade.md) provides similar functionality for fluid tanks next to the adapter.
你还可以安装[MFU](../item/mfu.md) 来与更远的方块交互
