# 拆解器

![Build it, tear it down.](oredict:oc:disassembler)

可以将大多数电脑拆成零件. 常用来回收不用的零件或者合错的东西，比如没有烧入系统或者程序的机器人

这会花费一些时间和能源，也可能被吞配件。