# World Sensor Card

![To boldly go...](oredict:oc:worldSensorCard)

世界传感器卡允许读取大气，重力等世界信息，通常用于加入了星系mod的情况，用于调节在空间内工作的机器人