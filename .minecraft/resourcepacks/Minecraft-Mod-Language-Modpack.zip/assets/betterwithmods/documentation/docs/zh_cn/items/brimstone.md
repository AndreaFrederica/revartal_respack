![硫磺](item:betterwithmods:material@25)

硫磺是一种含有二氯氧化硫的材料，可以和[硝石](niter.md)、[煤粉](carbon_dust.md)一起制作火药。
