To get started, [sign the Contributor License Agreement](https://cla-assistant.io/CovertJaguar/Railcraft-3D).
